gachaQueryTypeIds = ["100", "200", "301", "302"]
gachaQueryTypeNames = ["新手祈愿", "常驻祈愿", "角色活动祈愿", "武器活动祈愿"]
gachaQueryTypeDict = dict(zip(gachaQueryTypeIds, gachaQueryTypeNames))
gacha_type_dict = {
    "100": "新手祈愿",
    "200": "常驻祈愿",
    "301": "角色活动祈愿",
    "302": "武器活动祈愿",
    "400": "角色活动祈愿-2",
}
